﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SLMS.Entity
{
    public class ErrorEntity
    {
        public int ErrorID { get; set; }
        public DateTime ErrorDateTime { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorDescription { get; set; }
        public Int16 UserID { get; set; }
    }
}