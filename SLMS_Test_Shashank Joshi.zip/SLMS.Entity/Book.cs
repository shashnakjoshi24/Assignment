﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SLMS.Entity
{
    public class Book
    {
        private int _id;
        private string _bookTitle;
        private string _publishYear;
        private bool _isAvailable;
        private double _coverPrice;


        public int Id
        {
            get => _id;
            set => _id = value;
        }

        public string BookTitle
        {
            get => _bookTitle;
            set => _bookTitle = value;
        }

        public string ISBN { get; set; }

        public string PublishingYear
        {
            get => _publishYear;
            set => _publishYear = value;
        }

        public bool IsAvailable
        {
            get => _isAvailable;
            set => _isAvailable = value;
        }

        public double Price
        {
            get => _coverPrice;
            set => _coverPrice = value;
        }

        public User Borrower { get; set; }
    }
}
