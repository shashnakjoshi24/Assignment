﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SLMS.DataContext;
using SLMS.Entity;
using SLMS.Utilities;

namespace SLMS_Test
{
    public partial class Contact : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int selectedBookID = 0;
            if (!String.IsNullOrWhiteSpace(Request.QueryString["bookID"]))
                selectedBookID = int.Parse(Request.QueryString["bookID"]);
            else { }
            // to do error message

            lblCheckOutDate.Text = DateTime.Now.ToString();
            lblReturnDate.Text = Utilities.getDateAfterSpecifiedBusinessDays(15).ToString();

            DisplayBookCheckOutHistory(selectedBookID);

        }
        private void DisplayBookCheckOutHistory(int bookId)
        {
            GenericDatContext dbOperations = new GenericDatContext();
            List<CheckOutSummery> borrowers = dbOperations.GetCheckOutSummeryByBook(bookId);

            HistoryList.DataSource = borrowers;
            HistoryList.DataBind();


        }
        protected void btnCheckOut_Click(object sender, EventArgs e)
        {
            int selectedBookID = 0;
            if (!String.IsNullOrWhiteSpace(Request.QueryString["bookID"]))
                selectedBookID = int.Parse(Request.QueryString["bookID"]);
            else
            {
                Utilities.setPageMessage("Please select a book.", Utilities.severity.error, Page.Master);
                return;
            }
            
            DataEntryDataContext dbOperations = new DataEntryDataContext();

            string bookName = txtName.Text;
            string mobileNo = txtMobile.Text;
            string nationalID = txtNationalID.Text;
            DateTime checkOutDate = DateTime.Parse(lblCheckOutDate.Text);

            CheckOutSummery checkOutSummery = new CheckOutSummery();
            checkOutSummery.Book.Id = selectedBookID;
            checkOutSummery.User.Id = dbOperations.GetUserIdByMobileNumber(mobileNo);
            checkOutSummery.CheckOutDate = checkOutDate;
            int result = dbOperations.InsertBorrowingInformation(checkOutSummery);

            if (result == 0)
            {
                Utilities.setPageMessage("Encountered an error while checking out.", Utilities.severity.error, Page.Master);
                
                return;
            }

            Utilities.setPageMessage("Book has been checked out in the name of " + txtName.Text, Utilities.severity.info, Page.Master);

            DisplayBookCheckOutHistory(selectedBookID);
        }

    }
}