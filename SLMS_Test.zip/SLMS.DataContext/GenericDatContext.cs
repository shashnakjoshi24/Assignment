﻿using SLMS.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Data.Linq;
using SLMS.Entity;

namespace SLMS.DataContext
{
    public class GenericDatContext:System.Data.Linq.DataContext
    {
        public GenericDatContext() : base(ApplicationConfiguration.ConnectionString)
        {
            CommandTimeout = 7200;
        }

        public List<Book> GetBookList()
        {
            string query = "SELECT * FROM BOOK";
            return ExecuteQuery<Book>(query).ToList();
        }

        public List<CheckOutSummery> GetCheckOutSummeryForAllBooks()
        {
            string query = "SELECT * FROM CheckOutSummery COS INNER JOIN [dbo].[User] U ON COS.[User] = U.Id INNER JOIN Book B ON COS.Book = B.Id";
            return ExecuteQuery<CheckOutSummery>(query).ToList();
        }
        public List<CheckOutSummery> GetCheckOutSummeryByUser(int userId)
        {
            string query = "SELECT * FROM CheckOutSummery COS INNER JOIN [dbo].[User] U ON COS.[User] = U.Id INNER JOIN Book B ON COS.Book = B.Id WHERE U.Id = {0}";
            return ExecuteQuery<CheckOutSummery>(string.Format(query, userId)).ToList();
        }
        public List<CheckOutSummery> GetCheckOutSummeryByBook(int bookId)
        {
            string query = "SELECT * FROM CheckOutSummery COS INNER JOIN [dbo].[User] U ON COS.[User] = U.Id INNER JOIN Book B ON COS.Book = B.Id WHERE B.Id = {0}";
            return ExecuteQuery<CheckOutSummery>(string.Format(query, bookId)).ToList();
        }
        public int GetUserIdByMobileNumber(string MobileNumber)
        {
            string query = "SELECT Id FROM  [dbo].[User] U  [MobileNumber] = {0}";
            return ExecuteQuery<int>(string.Format(query, MobileNumber)).ToList().FirstOrDefault();
        }
    }
}
